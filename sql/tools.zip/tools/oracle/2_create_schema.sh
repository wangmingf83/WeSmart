sqlplus -s ROOT/123456@//localhost/XEPDB1 @/tmp/schema.sql
